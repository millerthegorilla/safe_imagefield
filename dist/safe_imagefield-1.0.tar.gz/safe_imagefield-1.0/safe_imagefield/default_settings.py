CLAMAV_SOCKET = 'unix:///var/run/clamav/clamd.ctl'

CLAMAV_TIMEOUT = None
