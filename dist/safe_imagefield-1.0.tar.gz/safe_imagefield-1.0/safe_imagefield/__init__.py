# this module, safe_imagefield, is based upon safefilefield by vladislav bakin :
# https://pypi.org/project/django-safe-filefield/